# Fast Car — Backend V2

## Avvio locale
1. Installa Node.js.
2. Apri il terminale nella cartella.
3. Esegui `npm install`.
4. Copia `.env.example` in `.env`.
5. Inserisci la tua `sk_test_...` SOLO nel file `.env`.
6. Esegui `npm start`.
7. Apri `http://localhost:4242`.
8. Gestionale: `http://localhost:4242/admin.html`.

Il progetto crea Checkout Sessions Stripe. Il database attuale è un JSON locale, sufficiente per il test iniziale.

## Prima del live
- database vero
- autenticazione gestionale
- webhook Stripe per confermare il pagamento
- HTTPS
- Stripe Connect per il partner
- regole per disponibilità, cancellazioni e rimborsi
- verifica fiscale/contrattuale
